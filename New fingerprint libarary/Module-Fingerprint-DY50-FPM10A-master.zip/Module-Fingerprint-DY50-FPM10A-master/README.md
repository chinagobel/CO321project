# Module-Fingerprint-DY50-FPM10A
Bismillah

Assalamualaikum Warakhmatullahi Wabarakatuh

Hello brother.... :D, May Allah help you, in any condition, everywhere, and everytime. Aaaminn,..
Let me introduce my self, maybe we can be a friend, only friend yaaa..., hihihi
I'm Hanif Izzudin Rahman, come from Indonesia

Here, i will post you about my project when i spent my experience internship in Bandung.

This project, i adopt from AdaFruit Fingerprint Sensor Library and Jerenomico codes. they are very deserving my project, but i will give you something that maybe, some people still confuse to learn fingerprint module.
