
[ Match 1:1 ]
al
Found fingerprint sensor!
Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...

[ Match 1:1 ]

go to hwSerial
Found fingerprint sensor!
Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
Searching ID #2
==> Load FlashMemory 2 to CharBuffer
[ UNKNOWN ERROR ]12
Waiting for valid finger as ID #2
,,,,,,,,,,
Image taken
Succes image2Tz
	 ===??? [ DOESN'T Match ] as ID #2

Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
Searching ID #1
==> Load FlashMemory 1 to CharBuffer
Template 1 loaded
Waiting for valid finger as ID #1
,,,,,
Image taken
Succes image2Tz
	 ===>>> [ MATCH !!! ] as ID #1

Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
Searching ID #3
==> Load FlashMemory 3 to CharBuffer
Template 3 loaded
Waiting for valid finger as ID #3
,,,,,,,,
Image taken
Succes image2Tz
	 ===>>> [ MATCH !!! ] as ID #3

Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
Searching ID #7
==> Load FlashMemory 7 to CharBuffer
Template 7 loaded
Waiting for valid finger as ID #7
,,,,,,,
Image taken
Succes image2Tz
	 ===??? [ DOESN'T Match ] as ID #7

Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
Searching ID #7
==> Load FlashMemory 7 to CharBuffer
Template 7 loaded
Waiting for valid finger as ID #7
,,,,,,,
Image taken
Succes image2Tz
	 ===??? [ DOESN'T Match ] as ID #7

Ready to match 1:1 a fingerprint!
Please type in the ID # (from 1 to 127) you want to match...
