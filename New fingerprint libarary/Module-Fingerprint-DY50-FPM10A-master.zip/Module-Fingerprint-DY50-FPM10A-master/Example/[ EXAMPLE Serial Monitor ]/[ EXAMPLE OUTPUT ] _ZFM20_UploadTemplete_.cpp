
[ Upload + Store FlashMemory + Show Templete ]

go to hwSerial
Found fingerprint sensor!

===> Write Packet SUKSES

==>[SUKSES] StoreModel + ID = 12 Stored!
