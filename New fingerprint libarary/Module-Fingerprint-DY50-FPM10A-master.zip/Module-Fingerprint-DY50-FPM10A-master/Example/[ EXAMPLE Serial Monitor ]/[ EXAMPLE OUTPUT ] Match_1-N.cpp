
[ Match 1:N ]

.
[ Match 1:N ]

go to hwSerial
Found fingerprint sensor!
Ready to match 1:N a fingerprint!
........................
Image taken
Image converted
==> Found a print match!
Found ID #1 with confidence of 108
.......
Image taken
Image converted
==> Found a print match!
Found ID #7 with confidence of 108
........
Image taken
Image converted
==> Found a print match!
Found ID #3 with confidence of 108
.........
Image taken
Image converted
==> Did not find a match
............
Image taken
Image converted
==> Found a print match!
Found ID #1 with confidence of 108
...............................................